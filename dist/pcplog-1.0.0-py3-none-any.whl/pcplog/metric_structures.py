import re
import copy
from abc import abstractmethod
from operator import itemgetter
from aenum import Enum


class Threshold:
    def __init__(self, name, over, value, time, fixed_value):
        self.name = name
        self.over = over
        self.value = value
        self.time = time
        self.fixed_value = fixed_value

    def get_name_value(self, arg):
        return self.name

    def change_value_by(self, num):
        self.value = self.value * num


class CustomError(Exception):
    def __init__(self, message=None):
        if message:
            self.message = message
        else:
            self.message = None

    def __str__(self):
        if self.message:
            return self.message
        else:
            return "CustomError has been raised."


class WrongInputError(CustomError):
    def __init__(self, *args):
        if args:
            CustomError.__init__(self, "InputError has been raised," + args[0])
        else:
            CustomError.__init__(self, "InputError has been raised.")


class EmptyError(CustomError):
    def __init__(self, *args):
        if args:
            CustomError.__init__(self, "InputError has been raised," + args[0])
        else:
            CustomError.__init__(self, "InputError has been raised.")


def time_average(values_fst, values_snd):
    var = values_fst[MetricOrder.TIME_AVERAGE.value] * values_fst[MetricOrder.TOTAL.value] + \
          values_snd[MetricOrder.TIME_AVERAGE.value] * values_snd[MetricOrder.TOTAL.value]
    return var / (values_fst[MetricOrder.TOTAL.value] + values_snd[MetricOrder.TOTAL.value])


class MetricOrder(Enum):
    METRIC_NAME = 0
    INSTANCE_NAME = 1
    STOCHASTIC_AVERAGE = 2
    TIME_AVERAGE = 3
    MINIMUM = 4
    MAXIMUM = 5
    TOTAL = 6
    UNIT = 7


class ValueOrder(Enum):
    AVERAGE = 0
    MIN = 1
    MAX = 2
    SUM = 3


class Metric:
    def __init__(self, name, description, path):
        self.name = name.strip()
        self.description = description.strip()
        self.path = path.strip()

    @abstractmethod
    def read_file_raw(self, path):
        pass

    @abstractmethod
    def check_compatibility(self):
        pass


class MetricChart(Metric):
    def __init__(self, name, description, path):
        Metric.__init__(self, name, description, path)
        self.unit_names = []
        self.units = []
        self.values = []
        self.read_file_raw(path)
        self.delete_undefined()
        self.count_units()
        self.check_compatibility()

    def read_file_raw(self, path):
        """
        Read data from file in path and save all important values.

        :param path: Path to text file with values in correct format.
        :return: Nothing or ImportError if is something wrong with file.
        """
        file = open(path, "r")
        if not file:
            raise CustomError("Not readable file to parsing.")
        line = file.readline()
        self.unit_names = re.split(',', line)
        self.unit_names = list(map(lambda x: x.strip(), self.unit_names))
        line = file.readline()
        self.units = re.split(',', line)
        self.units = list(map(lambda x: x.strip(), self.units))

        while line:
            line = re.split(',', line)
            try:
                value = [int(line[0].strip())]
                for i in range(1, len(line)):
                    try:
                        value.append(float(line[i]))
                    except:
                        value.append(None)
                self.values.append(value)
            except:
                pass
            line = file.readline()

    def sort(self):
        """
        Sort values of metric by time.
        """
        self.values = sorted(self.values, key=itemgetter(0))

    def get_size(self):
        """

        :return: size of list of values
        """
        if self.values:
            return len(self.values)
        else:
            return 0

    def get_values(self, index):
        if self.get_size() <= index:
            return []
        else:
            return self.values[index]

    def get_time_value(self, index):
        """

         :param index: index of value in list
         :return: time of concrete index value
        """
        if index < self.get_size():
            return self.values[index][0]
        return None

    def get_value(self, time_i, pos_i):
        """

        :param time_i: index of values that we want
        :param pos_i: index of concrete value in values
        :return:  concrete value
        """
        if self.get_size() > time_i and pos_i < len(self.values[time_i]):
            return self.values[time_i][pos_i]
        else:
            return None

    def set_value(self, time_i, pos_i, value):
        """

        :param time_i: index of values that we want
        :param pos_i: index of concrete value in values
        :param value: value that will replace old value in self.values[time_i][pos_i]
        """
        if time_i <= self.get_size() and pos_i < len(self.values[time_i]):
            self.values[time_i][pos_i] = value

    def count_units(self):
        """
        Function which will convert values to basic unit. Called in initialization of object.
        """
        for i in range(1, len(self.units)):
            unit = 1
            if 'Kb' in self.units[i]:
                unit = 10 ** 3
            elif 'Mb' in self.units[i]:
                unit = 10 ** 6
            elif 'Gb' in self.units[i]:
                unit = 10 ** 9
            elif 'millisec / sec' in self.units[i]:
                unit = 0.001
            self.units[i] = "basic"
            for j in range(len(self.values)):
                if self.get_value(j, i) is not None:
                    self.set_value(j, i, self.get_value(j, i) * unit)

    def count_avg(self, index):
        """
        Function which will count average of values in index and return result
        :param index: Index of values from which we want average
        :return: Average of values in self.values[index]
        """
        avg = 0
        count = 0
        for i in range(1, len(self.get_values(index))):
            if (self.values[index][i]) is None:
                pass
            else:
                count += 1
                avg = self.values[index][i] + avg
        if count == 0:
            return None
        return avg / count

    def count_sum(self, index):
        """
        Function which will count sum of values in index and return result
        :param index: Index of values from which we want sum
        :return: Sum of values in self.values[index]
        """
        sum = 0
        non_val = True
        for i in range(1, len(self.values[index])):
            if (self.values[index][i]) is None:
                pass
            else:
                sum = sum + self.values[index][i]
                non_val = False
        if non_val:
            return None
        return sum

    def get_values_by_name(self, name):
        """
        Function which filter return array with values only for our name
        :param name: Name of value that we want to filter
        :return: List of values in format [[TIME_VALUE, VALUE_OF_SEARCHED_NAME]]
        """

        index = None
        for i in range(len(self.unit_names)):
            if name in self.unit_names[i]:
                index = i
                break
        if index is None:
            raise EmptyError(
                "Value name %s  in function chart.get_values_by_name in metric %s  in file %s  not found."
                % (name, self.name, self.path))
        return list(map(lambda x: [x[0], x[index]], self.values))

    def count_list(self, method):
        """
        Method which take some method as parameter,apply it for whole list and return list as result
        from this
        operations. Used for sum and average.
        :param method: Method which will apply for single index value and return result
        :return: List of results from method.
        """

        return_list = []
        for i in range(self.get_size()):
            if method(i) is not None:
                return_list.append(method(i))
        return return_list

    def delete_undefined(self):
        """
        Delete all undefined values(None). Used because PCP often returns None values in start
        and in the end.
        """
        self.values = list(filter(lambda x: is_none(x), self.values))

    def get_max(self):
        """
        Return max value from all values
        """
        max = 0
        for i in self.values:
            for j in range(1, len(i)):
                if isinstance(i[j], (int, float)) and i[j] > max:
                    max = i[j]
        return max

    def get_value_by_time(self, time):
        for i in self.values:
            if i[0] == time:
                return i[1:]
        return [None]

    def check_compatibility(self):
        if len(self.values) == 0:
            raise EmptyError(
                "Metric chart %s  from file %s  without values." % (self.name, self.path))
        for i in self.values:
            if len(i) != len(self.unit_names):
                raise WrongInputError(
                    "Data from metric %s  from file %s  are in bad format" % (self.name, self.path))

    def get_name_value(self, index):
        if index < 0 or index > len(self.unit_names):
            raise IndexError("Index %s  is not correct in Chart.get_name_value()" % (index))
        return self.unit_names[index]

    def filter(self, threshold, time, function):
        basic = -1
        while (basic * -1) < len(self.units):
            values = self.get_values_by_name(self.unit_names[basic])
            values = list(
                filter(lambda x: x[-1] is not None and function(x[-1], threshold), values))
            if len(values) <= len(self.values) * time:
                for i in range(len(self.values)):
                    del self.values[i][basic]
                del self.units[basic]
                del self.unit_names[basic]
            else:
                basic = basic - 1
        return 0

    def change_value_by(self, num):
        for value_index in range(len(self.values)):
            for index in range(1, len(self.unit_names)):
                self.values[value_index][index] *= num


def bigger(value, threshold):
    return value > threshold


def less(value, threshold):
    return value < threshold


class MetricBasic(Metric):
    def __init__(self, name, description, path):
        Metric.__init__(self, name, description, path)
        self.values = [None for i in range(len(MetricOrder))]
        self.read_data_raw(path)

    def get_unit(self):
        if len(self.values) != 8:
            raise WrongInputError(
                "Undefined unit in MetricBasic: %s  in %s " % (self.name, self.path))
        return self.values[MetricOrder.UNIT.value]

    def read_file_raw(self, path):
        """
        Function which reads file on path and saves data, if are data in bad format or insufficient,
         it raises error.
        :param path: Path to file with log data
        :return: Data saved in list.
        """
        file = open(path, "r")
        if not file:
            raise CustomError("Problem with opening file %s " % self.path)
        temp_array = file.readlines()
        filtered_entry = list(filter(lambda x: re.search("^%s,.*" % self.name, x), temp_array))
        filtered_entry = list(map(lambda x: x.strip() and x.strip("\n"), filtered_entry))
        if len(filtered_entry) != 1:
            raise EmptyError("Metric %s  in file %s  not found or there is more metrics." % (
                self.name, self.path))
        filtered_entry = filtered_entry[0].split(",")
        if len(filtered_entry) != 8:
            raise WrongInputError(
                "Insufficient archive data in metric %s  from file %s " % (self.name, self.path))
        for i in range(2, 7):
            try:
                filtered_entry[i] = float(filtered_entry[i])
            except:
                raise WrongInputError(
                    "Bad metric format in metric %s  in file %s ." % (self.name, self.path))
        return filtered_entry

    def read_data_raw(self, path):
        filtered_entry = self.read_file_raw(path)
        self.values = copy.deepcopy(filtered_entry)
        self.check_compatibility()

    def check_compatibility(self):
        """
        Check compability of metric. If is metric in bad format it raises WrongInputError.
        """
        if len(self.values) != 8:
            raise WrongInputError(
                "Data from metric %s  from file %s  are in bad format." % (self.name, self.path))
        for i in range(2, 7):
            if type(self.values[i]) is not float:
                raise WrongInputError("Data from metric %s  from file %s  are in bad format." % (
                    self.name, self.path))

    def get_value(self, index):
        """

        :param index: Index of value which we want
        (the best way is to use value of Enum MetricOrder).
        :return: Value of concrete index
        """
        return self.values[index]


class MetricNode(Metric):
    def __init__(self, name, description, path):
        Metric.__init__(self, name, description, path)
        self.values = []
        self.read_data_raw(path.strip())

    def read_file_raw(self, path):
        file = open(path, "r")
        if not file:
            raise CustomError("File %s  to metric %s  not found." % (self.path, self.name))
        temp_array = file.readlines()
        filtered_entry = list(filter(lambda x: re.search("^%s,.*" % self.name, x), temp_array))
        if len(filtered_entry) == 0:
            raise EmptyError("Metric %s  in file %s  not found." % (self.name, self.path))
        filtered_entry = list(map(lambda x: x.split(","), filtered_entry))
        filtered_entry = list(filter(lambda x: len(x) == 8, filtered_entry))
        for index in range(len(filtered_entry)):
            filtered_entry[index] = list(map(lambda x: x.strip(), filtered_entry[index]))
            for i in range(2, 7):
                try:
                    filtered_entry[index][i] = float(filtered_entry[index][i])
                except:
                    raise WrongInputError(
                        "Values in %s  in file %s  are not numbers." % (self.name, self.path))
        return filtered_entry

    def read_data_raw(self, path):
        self.values = copy.deepcopy(self.read_file_raw(path))
        self.check_compatibility()

    def concat_data(self, path):
        filtered_entry = self.read_file_raw(path)
        deep_copy = copy.deepcopy(self.values)
        for index in range(len(filtered_entry)):
            temp = list(
                filter(lambda x: filtered_entry[index][MetricOrder.INSTANCE_NAME.value] in x,
                       deep_copy))
            if len(temp) == 0:
                deep_copy.append(copy.deepcopy(filtered_entry[index]))
            elif len(temp) == 1:
                new_value = self.update_values(filtered_entry[index], temp[0])
                deep_copy[deep_copy.index(temp[0])] = new_value
            else:
                return ImportError
        self.values = deep_copy
        self.check_compatibility()

    def update_values(self, values, new_value):
        values[MetricOrder.TIME_AVERAGE.value] = time_average(new_value, values)
        values[MetricOrder.TOTAL.value] = values[MetricOrder.TOTAL.value] + new_value[
            MetricOrder.TOTAL.value]
        values[MetricOrder.MINIMUM.value] = min(values[MetricOrder.MINIMUM.value],
                                                new_value[MetricOrder.MINIMUM.value])
        values[MetricOrder.MAXIMUM.value] = max(values[MetricOrder.MAXIMUM.value],
                                                new_value[MetricOrder.MAXIMUM.value])

        return values

    def count_avg(self, index):
        actual = 0
        for i in self.values:
            actual = i[index] + actual
        return (actual / (len(self.values)))

    def filter(self, name):
        self.values = list(
            filter(lambda x: name in x[MetricOrder.INSTANCE_NAME.value], self.values))
        self.check_compatibility()

    def check_compatibility(self):
        """
        Check compability of metric. If is metric in bad format it raises WrongInputError or EmptyError.
        """
        for i in self.values:
            if len(i) != 8:
                self.values.remove(i)
                continue
            for j in range(2, 7):
                if type(i[j]) is not float:
                    raise WrongInputError(
                        "Data from metric %s  from file %s are in bad format." % (
                            self.name, self.path))
        if len(self.values) == 0:
            raise EmptyError(
                "Data from metric %s  from file %s  are in bad format." % (self.name, self.path))

    def get_unit(self):
        if len(self.values[0]) != 8:
            raise WrongInputError(
                "Data in metric %s from %s in bad format." % (self.name, self.path))
        return self.values[0][MetricOrder.UNIT.value]

    def get_size(self):
        return float(len(self.values))


def divide(par1, par2):
    if par2 == 0:
        return None
    return par1 / par2


def plus(par1, par2):
    return par1 + par2


def count_metrics(fst_chart, snd_chart, fnc):
    """
    Function which take 2 lists and executes fnc on Values with same Time.
    :param fst_chart: List of lists in format [ [Time(int), Value(float or None)] ]
    :param snd_chart: Same as fst_chart
    :param fnc:  Function which is executed on values with same time.
    :return: List with values returned by fnc.
    """
    fst_index = 0
    snd_index = 0
    return_list = []
    while fst_index < len(fst_chart) and snd_index < len(snd_chart):
        if fst_chart[fst_index][0] == snd_chart[snd_index][0] and fst_chart[fst_index][
            1] is not None \
                and snd_chart[snd_index][1] is not None:
            return_list.append(
                [fst_chart[fst_index][0], fnc(fst_chart[fst_index][1], snd_chart[snd_index][1])])
            fst_index += 1
            snd_index += 1

        elif fst_chart[fst_index][0] < snd_chart[snd_index][0] or fst_chart[fst_index][1] is None:
            fst_index += 1
        elif fst_chart[fst_index][0] > snd_chart[snd_index][0] or snd_chart[snd_index][1] is None:
            snd_index += 1
        else:
            snd_index += 1
            fst_index += 1
    return return_list


def is_none(values):
    """
    Check if are in list only None values (except first, which is time value). If there are only None values, return
    False, else True.
    :param values: List with values.
    :return: If there are only None values, return False, else True.
    """
    for i in range(1, len(values)):
        if values[i] != None:
            return True
    return False
