import os
import shutil
from typing import List, Dict

from pcplog.settings import TEST_PARAMETERS
from pcplog.output_structures import CqeNode, CqeOutputFormat
from pcplog.alerts.chart_alerts import chart_entry, CustomError
from pcplog.parser import request_archive, parse_test_metadata, parse_json_parameters, \
    request_job_metadata_json, extract_files, parse_data_log, extract_node_metadata, \
    normalize_maximum_in_plots, format_to_output, delete_dir, tag_nodes
import jsonpickle
import tempfile
import threading

''' 
TODO:
2.Otypovat a dopsat dokumentaci.
6.Zmenit strukturu projektu a usporadani files, at davaji smysl.
7.Ocheckovat spravne nazvy promennych.
'''


class NodeThread(threading.Thread):
    def __init__(self, name, function, *args):
        threading.Thread.__init__(self)
        self.name = name
        self.args = args
        self.function = function

    def run(self):
        self.function(*self.args)


def execute_test(parameter, node_name: str, node: CqeNode, nodes_results,
                 cqe_format: bool) -> NodeThread:
    try:
        test_result = NodeThread(parameter["id"], chart_entry, parameter, node_name, node,
                                 nodes_results, cqe_format)

        test_result.start()
        return test_result
    except CustomError as error:
        print(error)
        pass


def test_logic(job_id: int, input_pcp_archive: str = "",
               input_system_metadata: str = "", xml_metadata: str = "", time_shift=1):
    if input_pcp_archive is "":
        pcp_archive: str = request_archive(job_id)
    else:
        pcp_archive: str = input_pcp_archive
    pcp_log_paths: List[str] = extract_files(
        pcp_archive)  # extract archive and give paths to nodes
    if input_system_metadata is "":
        metadata_file_path: str = request_job_metadata_json(job_id)
    else:
        metadata_file_path: str = input_system_metadata
    test_parameters: dict = parse_json_parameters(TEST_PARAMETERS)
    output: CqeOutputFormat = CqeOutputFormat(job_id)
    parse_test_metadata(metadata_file_path, output.metadata, time_shift)
    threads: List[NodeThread] = []
    to_print: Dict = {}
    for i in range(len(pcp_log_paths)):
        output.add_node(pcp_log_paths[i].split('/')[-1])
        node: CqeNode = output.nodes[-1]
        summary_log: str = parse_data_log(pcp_log_paths[i])
        extract_node_metadata(summary_log, node.metadata)
        to_print[node] = {}
        for parameter in test_parameters:
            test_thread = execute_test(parameter,
                                       pcp_log_paths[i],
                                       node,
                                       to_print[node], True)
            threads.append(test_thread)

    for t in threads:
        t.join()
    format_to_output(to_print)
    normalize_maximum_in_plots(output, to_print)
    tag_nodes(output, xml_metadata)
    json_str = jsonpickle.encode(output, unpicklable=False)
    return json_str


def make_tests_cqe(entry_id: int, input_pcp_archive: str = "",
                   input_system_metadata: str = "", xml_metadata: str = "", time_shift=1):
    start_dir: str = tempfile.tempdir
    tmpdir: str = tempfile.mkdtemp()
    tempfile.tempdir = tmpdir  # create new tempdir and set it as default
    try:
        return test_logic(entry_id, input_pcp_archive,
                          input_system_metadata, xml_metadata, time_shift)
    except Exception as e:
        raise e
    finally:
        tempfile.tempdir = start_dir
        shutil.rmtree(tmpdir)
