import functools
import json
import requests
import tempfile
from typing import Dict, List

import xml.etree.ElementTree as ET

from pcplog.output_structures import TestrunMetadata, NodeMetadata, CqeOutputFormat
from pcplog.prints import return_values_thresholds, multiply_thresholds, datafile_output_variables, \
    datafile_output
from xmlrpc.client import ServerProxy

from subprocess import Popen, PIPE
from pcplog.metric_structures import EmptyError, WrongInputError

from pcplog.settings import TIMEFRAME, CHART_GROUPS_PATH, BEAKER_URL, BEAKER_PROXY_SERVER


def tag_nodes(output: CqeOutputFormat, tag_file :str =""):
    """
    Function which downloads results.xml from beaker and tag driver node, so user can check which
    system is driver from the output
    :param output: Output which has all information from pcp-analysis.
    """
    if tag_file != "":
        result_xml = open(tag_file, "rb").read()
    else:
        result_xml = requests.get("{}/bkr/jobs/{}.xml".format(BEAKER_URL, output.id)).content
    parsed_xml = ET.fromstring(result_xml)
    for recipe in parsed_xml.find("recipeSet"):
        if recipe.attrib["whiteboard"] == "Driver":
            node = next(filter(lambda x: x.name == recipe.attrib["system"], output.nodes))
            node.driver = True


def request_archive(job_id: int) -> str:
    """
    Download and save pcp *.tar.gz archive from Beaker platform and returns path to it as url.
    :param job_id: ID of beaker job, for which should be pcp *.tar.gz archive downloaded.
    :return: Path to downloaded archive as str.
    """
    rpc = ServerProxy(BEAKER_PROXY_SERVER)
    rpc = rpc.taskactions.files('J:%s' % job_id)
    rpc = list(filter(lambda x: 'pcp' in x['url'], rpc))[0]
    archive = requests.get("%s%s" % (rpc['server'], rpc['filename']))
    file = tempfile.NamedTemporaryFile(delete=False, suffix=".tar.gz")
    open(file.name, 'wb').write(archive.content)
    return file.name


def parse_data_log(archive: str) -> str:
    """
    Gets pcp archive as parameter,executes pmlogsummary command on it and return path to file
    of pmlogsummary result.
    :param archive: Path to archive on which will be command executed.
    :return: Path to file in which is data from pmlogsummary command.
    """
    file = tempfile.NamedTemporaryFile(delete=False)
    process = Popen("pmlogsummary  -aF %s" % (archive), stdout=file, stderr=PIPE, shell=True,
                    universal_newlines=True)
    process.wait()

    _, error = process.communicate()
    if error:
        raise SystemError
    return file.name


def parse_data_chart(archive: str, command: str) -> str:
    """
    Function which takes path to directory with pcp files and command, which is name of metric.
    If there are more metricsin that directory and some of them doesnt have data from this metric,
    function will filter that datasets and execute command only on valid ones.

    :param archive: Path to directory with pcp datasets.
    :param command: Name of metric, from which we want to have data.
    :return: Path to file with data from metric.
    """
    process = Popen("ls %s | grep '.*[.]index' " % archive, stdout=PIPE, stderr=PIPE, shell=True,
                    universal_newlines=True)
    process.wait()
    output, error = process.communicate()
    output = (str(output)).split("\n")
    output = list(filter(lambda x: x, output))
    if len(output) == 0:
        raise EmptyError("Metric %s in log %s not found." % (command, archive))
    commands = ""
    for i in output:
        process = Popen("pminfo -a %s/%s | grep %s " % (archive, i, command), stdout=PIPE,
                        stderr=PIPE,
                        shell=True,
                        universal_newlines=True)
        process.wait()
        output, error = process.communicate()
        if str(output):
            commands = commands + archive + "/" + i + " "
    commands: str = commands.strip()
    archived_log = tempfile.NamedTemporaryFile(delete=False)
    process = Popen("pmlogextract %s %s" % (commands, archived_log.name), stdout=PIPE, stderr=PIPE,
                    shell=True,
                    universal_newlines=True)
    process.wait()
    _, _ = process.communicate()
    file = tempfile.NamedTemporaryFile(delete=False)
    p = Popen("pminfo -a %s | pmdumptext -mu -d ',' -t %ss -f '%s' %s -a %s" % (
        archived_log.name, TIMEFRAME, "%s", command, archived_log.name), stdout=file, stderr=PIPE,
              shell=True)
    p.wait()

    output, error = p.communicate()

    return file.name


def extract_files(path: str) -> List[str]:
    """
    Extract archive from Beaker platform and saves path to concrete nodes in list of paths.
    This list is then returned.
    :param path: Path of PCP archive which will be extract.
    :return: List of paths to pcp archives.
    """
    dir = tempfile.mkdtemp()
    p = Popen("tar -xf %s -C %s" % (path, dir), stderr=PIPE, shell=True)
    p.wait()

    output, error = p.communicate()
    p = Popen("ls %s" % dir, stdout=PIPE, stderr=PIPE, shell=True)
    p.wait()

    archive, error = p.communicate()
    archive = archive.decode("utf-8")
    archive = archive.strip('\n')
    p = Popen("ls %s/%s" % (dir, archive), stdout=PIPE, stderr=PIPE, shell=True)
    p.wait()

    logs, error = p.communicate()
    logs = logs.decode("utf-8")
    logs = logs.strip('\n')
    logs = logs.split('\n')
    logs = list(filter(lambda x: 'pmlogger' not in x, logs))
    logs = list(map(lambda x: '%s/%s/%s' % (dir, archive, x), logs))
    return logs


def request_job_metadata_json(job_id: int) -> str:
    """
    This function gets job_id and requests JSON metadata from Beaker platform and saves
    them in file. Returns path of that file.
    :param job_id: Id of job in Beaker.
    :return: Path to file with loaded JSON from Beaker.
    """
    rpc = ServerProxy(BEAKER_PROXY_SERVER)
    rpc = rpc.taskactions.files('J:%s' % job_id)
    rpc = list(filter(lambda x: 'results.json' in x['url'], rpc))[0]
    r = requests.get("%s%s" % (rpc['server'], rpc['filename']))
    file = tempfile.NamedTemporaryFile(delete=False, suffix=".json")
    open(file.name, 'wb').write(r.content)
    return file.name


def extract_node_metadata(summary_file: str, node_metadata: NodeMetadata) -> None:
    """

    :param summary_file:
    :param node_metadata:
    """
    with open(summary_file, "r") as file:
        pcp_log_list = file.read().split('\n')
        pcp_log_list = [row for row in pcp_log_list if "hinv" in row]
        node_metadata.physical_memory = float(
            [row for row in pcp_log_list if "hinv.physmem" in row][0].split(',')[5])
        for cpu in [row for row in pcp_log_list if "hinv.cpu.clock" in row]:
            cpu_label = cpu.split(',')[1]
            cpu_clock = float(cpu.split(',')[5])
            cpu_bogomips = \
                float([row for row in pcp_log_list if
                       'hinv.cpu.bogomips,{}'.format(cpu_label) in row][0].split(',')[5])
            cpu_cache = float(
                [row for row in pcp_log_list if 'hinv.cpu.cache,{}'.format(cpu_label) in row][
                    0].split(',')[5])
            node_metadata.add_cpu(cpu_clock, cpu_cache, cpu_bogomips, cpu_label)


def parse_test_metadata(results_file: str, testrun_metadata: TestrunMetadata, time_shift: int) -> \
        None:
    """
    Parse test metadata from file in path results_file and saves it to testrun_metadata structure
    :param results_file: Path to file with JSON files from Beaker platform.
    :param testrun_metadata: TestrunMetadata object which saves all important metadata about
    nodes and job.
    """
    with open(results_file, "r") as file:
        results_file_json: dict = json.loads(file.read())
        testrun_metadata.load_test_info(results_file_json, time_shift)


def parse_json_parameters(path: str) -> Dict:
    """
    It gets path which is path to some file with JSON object. Then reads it and returns JSON object
    as a dict.
    :param path: Path to file with JSON object.
    :return: JSON object as Python data structure.
    """

    with open(path, 'r') as file:
        data = file.read().replace('\n', '')
        data = data.strip()
    return json.loads(data)


def get_chart_metric_details(path: str, id: str) -> Dict:
    """
    This function gets path to JSON_file with chart_metrics and choose one by parameter id.
    If there is no structure with that id, it raises Error.

    :param path: Path of JSON file with chart_metric parameters.
    :param id: Identification string of structure that we want to get.
    :return: Concrete structure of chart_metric from JSON file.
    """
    chart_metrics = parse_json_parameters(path)
    for structure in chart_metrics:
        if structure["id"].strip() == id.strip():
            return structure
    raise WrongInputError("Id of from tests not found in chart_metrics.json file.")


def format_to_output(to_print) -> None:
    chart_groups = parse_json_parameters(CHART_GROUPS_PATH)
    for node in to_print:
        for group in chart_groups:
            values, thresholds = return_values_thresholds(to_print[node], group["id"])
            if group["variable"]:
                thresholds = multiply_thresholds(values, thresholds)
            if "multiply" in group:
                for value in values:
                    value.change_value_by(group["multiply"])
                for threshold in thresholds:
                    threshold.change_value_by(group["multiply"])
            max_y = functools.reduce(lambda a, b: max(a, b),
                                     list(map(lambda x: x.get_max(), values)), 1)
            labels = ["Time"]
            for label in values:
                labels += label.unit_names[1:]

            if "labels" in group:
                labels = group["labels"]
                values, thresholds = datafile_output_variables(values, labels, thresholds)
                labels = ["Time"] + labels
            else:
                values = datafile_output(values)
            node.add_graph(group["id"], ' '.join(labels) + '\n' + values,
                           " ".join(list(map(lambda x: str(x.value), thresholds))), max_y)


def delete_dir(path: str) -> None:
    """
    Delete directory or raises error, when something happened.
    :param path: Path to directory
    :return: None, raises error if cannot delete directory.
    """
    p = Popen("rm -Rf {}".format(path), stdout=PIPE, stderr=PIPE, shell=True,
              universal_newlines=True)
    p.wait()
    _, error = p.communicate()
    if error:
        raise IOError


def normalize_maximum_in_plots(output, to_print):
    for plot in output.nodes[0].graph:
        label = plot.label
        max_y = functools.reduce(lambda a, b: max(a, b.max_y),
                                 list(map(lambda x: list(filter(lambda y: y.label == label,
                                                                x.graph))[0],

                                          output.nodes)),
                                 0)
        for node in to_print:
            for plot in node.graph:
                if plot.label == label:
                    plot.max_y = max_y
