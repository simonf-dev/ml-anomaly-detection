from pcplog.metric_structures import *
from pcplog.parser import *
from pcplog.prints import print_result
def basic_zero_alert(xml, pcp,output):
    """
    Function takes all metrics from XML file which have "zero" in category and run alerts-dev on them. Results are append
    to file "log.p".

    :param xml: XML file with metric instantions which should be alerted
    :param pcp: log file with PCP results
    """
    attributes = parse_data(xml, "zero", "basic")

    for i in attributes:
        metric = MetricBasic(i.find('name').text, i.find('description').text, pcp)
        if metric.get_value(MetricOrder.MAXIMUM.value) != 0:
            print_result(metric.name, metric.values[MetricOrder.MAXIMUM.value], 0,
                         "", [metric],output)


def cpu_idle_alert(threshold, xml, pcp,output):
    attributes = parse_data(xml, "cpu_idle", "node")
    for i in attributes:
        metric = MetricNode(i.find('name').text, i.find('description').text, pcp)
        stoch_avg = metric.count_avg(MetricOrder.TIME_AVERAGE.value)
        if stoch_avg < threshold:
            print_result(metric.name, stoch_avg, threshold,
                         "The speed of the CPU is limiting performance, stochastic average", [metric],output)


def cpu_usertime_alert(threshold, xml, pcp,output):
    attributes = parse_data(xml, "systime", "node")
    for i in attributes:
        metric = MetricNode(i.find('name').text, i.find('description').text, pcp)
        stoch_avg = metric.count_avg(MetricOrder.TIME_AVERAGE.value)
        if (stoch_avg > threshold):
            print_result("average %s" % metric.name,
                         stoch_avg, threshold,
                         "The CPU is executing too much system code", [metric],output)


def cpu_systime_alert(threshold, xml, pcp,output):
    attributes = parse_data(xml, "systime", "node")
    for i in attributes:
        metric = MetricNode(i.find('name').text, i.find('description').text, pcp)
        stoch_avg = metric.count_avg(MetricOrder.TIME_AVERAGE.value)
        if stoch_avg > threshold:
            print_result("average %s" % metric.name,
                         stoch_avg, threshold,
                         "The CPU is executing too much system code ", [metric],output)


def kernel_merging_alert(threshold, xml, pcp,output):
    attributes = parse_data(xml, "merge_u", "node")
    metric_utime = MetricNode(attributes[0].find('name').text, attributes[0].find('description').text, pcp)
    attributes = parse_data(xml, "merge_s", "node")
    metric_stime = MetricNode(attributes[0].find('name').text, attributes[0].find('description').text, pcp)
    metric_utime.filter("ksmd")
    metric_stime.filter("ksmd")
    if (metric_stime.count_avg(MetricOrder.TIME_AVERAGE.value) + metric_utime.count_avg(
            MetricOrder.TIME_AVERAGE.value) > threshold):
        print_result("%s +  %s" % (metric_stime.name, metric_utime.name),
                     metric_stime.count_avg(MetricOrder.MAXIMUM.value) +
                     metric_utime.count_avg(MetricOrder.MAXIMUM.value), threshold,
                     "Kernel SamePage Merging Daemon (ksmd) using too much time.", [metric_utime, metric_stime],output)




def storage_dm_total_alert(threshold, xml, pcp,output):
    attributes = parse_data(xml, "dm_total", "node")
    attributes_byte = parse_data(xml, "dm_bytes", "node")
    for i, j in zip(attributes, attributes_byte):
        metric_tot = MetricNode(i.find('name').text, i.find('description').text, pcp)
        metric_byte = MetricNode(j.find('name').text, j.find('description').text, pcp)
        for k, l in zip(metric_byte.values, metric_tot.values):
            if (l[MetricOrder.TIME_AVERAGE.value] == 0):
                continue
            if k[MetricOrder.TIME_AVERAGE.value] / (l[MetricOrder.TIME_AVERAGE.value]) < threshold:
                print_result(
                    "%s / %s %s" % (
                    metric_byte.name, metric_tot.name, metric_tot.values[MetricOrder.INSTANCE_NAME.value]),
                    k[MetricOrder.TIME_AVERAGE.value] / (l[MetricOrder.TIME_AVERAGE.value]),
                    threshold, "Excessively small sized operations for storage.", [metric_byte, metric_tot],output)


def memory_swappages_alert(threshold, xml, pcp,output):
    attributes = parse_data(xml, "swap", "basic")
    for i in attributes:
        metric = MetricBasic(i.find('name').text, i.find('description').text, pcp)
        if metric.get_value(MetricOrder.TIME_AVERAGE.value) > threshold:
            print_result("%s" % metric.name, metric.values[MetricOrder.MAXIMUM.value],
                         threshold,
                         "Not enough physical memory and data being moved out to swap space.",
                         [metric],output)


def memory_available_alert(threshold, xml, pcp,output):
    attributes = parse_data(xml, "physmem", "basic")
    metric_phys = MetricBasic(attributes[0].find('name').text, attributes[0].find('description').text, pcp)
    attributes = parse_data(xml, "availablemem", "basic")
    metric_ava = MetricBasic(attributes[0].find('name').text, attributes[0].find('description').text, pcp)
    if (metric_ava.get_value(MetricOrder.TIME_AVERAGE.value) / metric_phys.get_value(MetricOrder.TIME_AVERAGE.value)
            < threshold):
        print_result("%s / %s" % (metric_ava.name, metric_phys.name),
                     metric_ava.values[MetricOrder.TIME_AVERAGE.value] /
                     metric_phys.values[MetricOrder.TIME_AVERAGE.value], threshold,
                     "Running low on available memory.", [metric_phys, metric_ava],output)


def node_zero_alert(xml, pcp,output):
    """
        Function takes all metrics from XML file which have "zero" in category and run alerts-dev on them. Results are append
        to file "log.p".

        :param xml: XML file with metric instantions which should be alerted
        :param pcp: log file with PCP results
        """
    attributes = parse_data(xml, "zero", "node")
    for i in attributes:
        metric = MetricNode(i.find('name').text, i.find('description').text, pcp)

        for j in metric.values:
            if j[MetricOrder.MAXIMUM.value] > 0:
                print_result("%s" % {j.name, j[MetricOrder.METRIC_NAME]}, j[MetricOrder.MAXIMUM.value], 0,
                             "", [metric],output)

