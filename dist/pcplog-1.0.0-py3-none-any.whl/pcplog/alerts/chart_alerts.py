from pcplog.metric_structures import *
from pcplog.parser import *
from pcplog.prints import *
from pcplog.settings import TIMEFRAME, CHART_METRICS_PATH

GRAPH_AVA_DESCRIPTION = "The percentage of free memory in system, value 1 means that 100% is free in that time."


def basic_filter_threshold_alert(parameter, threshold, metrics, node, cqe, over):
    metric = metrics[0]
    if over:
        avg_list = list(filter(lambda x: x > threshold.value, metric.count_list(metric.count_avg)))
    else:
        avg_list = list(filter(lambda x: x < threshold.value, metric.count_list(metric.count_avg)))
    for i in range(metric.get_size()):
        metric.values[i] = [metric.values[i][0], metric.count_avg(i)]
    metric.unit_names[1] = parameter["name"]
    metric.name = parameter["id"]
    if len(avg_list) > threshold.time * metric.get_size() or len(avg_list) * TIMEFRAME > threshold.fixed_value:
        if cqe:
            node.add_warning(parameter["name"], float(len(avg_list)) / metric.get_size(),
                             threshold.value * parameter["warning"]["multiply"], threshold.time,
                             cqe_warning_output(parameter["warning"]["message"]),
                             parameter["warning"]["units"],threshold.fixed_value)
        else:
            print_result_chart(parameter["name"], float(len(avg_list)) / metric.get_size(), threshold.value,
                               threshold.time,
                               parameter["warning"], [metric], node)
    return metric


def basic_over_threshold_alert(parameter, threshold, metrics, node, cqe=False):
    return basic_filter_threshold_alert(parameter, threshold, metrics, node, cqe, True)


def basic_under_threshold_alert(parameter, threshold, metrics, node, cqe=False):
    return basic_filter_threshold_alert(parameter, threshold, metrics, node, cqe, False)


def kernel_merging_alert_chart(parameter, threshold, metrics, node, cqe=False):
    metric_utime = metrics[0]
    metric_stime = metrics[1]
    result_list = count_metrics(metric_stime.get_values_by_name('ksmd'),
                                metric_utime.get_values_by_name('ksmd'), plus)
    sum_list = list(filter(lambda x: x[1] > threshold.value, result_list))
    metric_utime.unit_names = ["Time", "ksmd_utime+stime"]
    metric_utime.values = result_list
    if len(sum_list) > threshold.time * len(result_list) or len(sum_list) * TIMEFRAME > threshold.fixed_value:
        if cqe:
            node.add_warning(metric_stime.name + metric_utime.name, float(len(sum_list)) /
                             float(len(result_list)), threshold.value * 100, threshold.time,
                             cqe_warning_output(" Kernel SamePage Merging Daemon (ksmd) using too much time "), "%",
                             threshold.fixed_value)
        else:
            print_result_chart(metric_stime.name + metric_utime.name, float(len(sum_list)) /
                               float(len(result_list)), threshold.value, threshold.time,
                               " Kernel SamePage Merging Daemon (ksmd) using too much time ", [metric_stime,
                                                                                               metric_utime], node)

    # graph_print(metric_utime , node , threshold , over=True , maximum=metric_utime.get_max())
    metric_utime.unit_names[1] = parameter["name"]
    metric_utime.name = parameter["id"]
    return metric_utime


def storage_busy_alert_chart(parameter, threshold, metrics, node, cqe=False):
    metric = metrics[0]
    for i in range(1, len(metric.unit_names)):
        values = metric.get_values_by_name(metric.get_name_value(i))
        values = list(filter(lambda x: x[1] is not None, values))
        sum_list = list(filter(lambda x: x[1] > threshold.value, values))
        if len(sum_list) > len(values) * threshold.time or len(sum_list) * TIMEFRAME > threshold.fixed_value:
            if cqe:
                node.add_warning(metric.name + "[" + metric.get_name_value(i) + "]",
                                 float(len(sum_list)) / metric.get_size(), threshold.value * 100, threshold.time,
                                 cqe_warning_output("Excessive waiting for storage "), "%", threshold.fixed_value)
            else:
                print_result_chart(metric.name + "[" + metric.get_name_value(i) + "]",
                                   float(len(sum_list)) / metric.get_size(), threshold.value, threshold.time,
                                   "Excessive waiting for storage ", [metric], node)

    metric.filter(threshold.value * 0.75, threshold.time, bigger)
    metric.name = parameter["id"]

    # if len(metric.unit_names) != 1:
    # graph_print(metric , node , threshold , maximum=metric.get_max())
    return metric


def storage_dm_write_read_alert_chart(parameter, threshold, metrics, node, cqe=False):
    metric_tot = metrics[0]
    metric_byte = metrics[1]
    for i in range(1, len(metric_tot.unit_names)):
        result_list = count_metrics(metric_byte.get_values_by_name(metric_byte.unit_names[i]),
                                    metric_tot.get_values_by_name(metric_tot.unit_names[i]), divide)
        for j in range(len(result_list)):
            metric_tot.values[j][i] = result_list[j][1]
        final_list = list(filter(lambda x: x[1] is not None and x[1] < threshold.value, result_list))
        if len(result_list) * threshold.time < len(final_list) or len(final_list) * TIMEFRAME > threshold.fixed_value:
            if cqe:
                node.add_warning(metric_tot.name + metric_byte.name, float(len(final_list)) /
                                 float(len(result_list)), threshold.value, threshold.time,
                                 cqe_warning_output(" Running low on available memory "), "kB", threshold.fixed_value)
            else:
                print_result_chart(metric_tot.name + metric_byte.name + "[ " + metric_tot.unit_names[i] + " ]",
                                   float(len(final_list)) /
                                   float(len(result_list)), threshold.value, threshold.time,
                                   " Running low on available memory ", [metric_tot, metric_byte], node)

    metric_tot.filter(threshold.value, threshold.time, less)
    metric_tot.name = parameter["id"]
    return metric_tot


def memory_available_alert_chart(parameter, threshold, metrics, node, cqe=False):
    metric_ava = metrics[0]
    metric_tot = metrics[1]
    avg_list = count_metrics(metric_ava.values, metric_tot.values, divide)
    fil_list = list(filter(lambda x: x[1] < threshold.value, avg_list))
    metric_ava.values = avg_list
    metric_ava.description = GRAPH_AVA_DESCRIPTION
    # graph_print(metric_ava , node=node , threshold=threshold , over=False , maximum=metric_ava.get_max())
    if len(fil_list) > threshold.time * len(avg_list) or len(fil_list) * TIMEFRAME > threshold.fixed_value:
        if cqe:
            node.add_warning(metric_ava.name + metric_tot.name, float(len(fil_list)) /
                             float(len(avg_list)), threshold.value, threshold.time,
                             cqe_warning_output(" Running low on available memory "), "%", threshold.fixed_value)
        else:
            print_result_chart(metric_ava.name + metric_tot.name, float(len(fil_list)) /
                               float(len(avg_list)), threshold, threshold.time,
                               " Running low on available memory ", [metric_tot, metric_ava], node)
    metric_ava.name = parameter["id"]
    metric_ava.unit_names[1] = parameter["name"]
    return metric_ava


def memory_swappages_alert_chart(parameter, threshold, metrics, node, cqe=False):
    metric = metrics[0]
    avg_list = list(filter(lambda x: x > threshold.value, metric.count_list(metric.count_sum)))
    for i in range(len(metric.values)):
        metric.values[i] = [metric.values[i][0], metric.count_sum(i)]
    if len(avg_list) > metric.get_size() * threshold.time or len(avg_list) * TIMEFRAME > threshold.fixed_value:
        if cqe:
            node.add_warning(metric.name, float(len(avg_list)) / metric.get_size(), threshold.value, threshold.time,
                             cqe_warning_output("Not enough physical memory and data being moved out to swap space."),
                             "swap pages", threshold.fixed_value)
        else:
            print_result_chart(metric.name, float(len(avg_list)) / metric.get_size(), threshold.value, threshold.time,
                               "Not enough physical memory and data being moved out to swap space.", [metric], node)
        # graph_print(metric , node , threshold , maximum=metric.get_max())
    metric.name = parameter["id"]
    metric.unit_names[1] = parameter["name"]
    return metric


def chart_entry(parameter, archive, node, to_print, cqe=False):
    metrics = []
    threshold = Threshold(name=parameter["threshold"]["name"], over=parameter["threshold"]["over"],
                          value=parameter["threshold"]["value"],
                          time=parameter["threshold"]["time"], fixed_value=parameter["threshold"]["fixed_value"])
    attributes = None
    for chart_id in parameter["metrics"]:
        attributes = get_chart_metric_details(CHART_METRICS_PATH, chart_id)
        metric = parse_data_chart(archive, attributes["command"])
        metrics.append(MetricChart(attributes["name"], attributes["description"], metric))
    metric_to_print = globals()[parameter["function_name"]](
        parameter, threshold,
        metrics, node,
        cqe)
    if parameter["plot_group"] in to_print:
        to_print[parameter["plot_group"]][0].append(metric_to_print)
        to_print[parameter["plot_group"]][1].append(threshold)
    else:
        to_print[parameter["plot_group"]] = ([metric_to_print], [threshold])
