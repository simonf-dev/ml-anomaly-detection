import datetime
from typing import List

VERSION_PLOT = 0


class Node():
    def __init__(self, name):
        self.name = name
        self.warnings = Warnings()
        self.graph = Graphs()

    def add_warning(self, message):
        self.warnings.add_warning(message)

    def add_graph(self, name, plot):
        self.graph.add_plot(name, plot)


class Warning():
    def __init__(self, data=""):
        self.data = data


class Plot():
    def __init__(self, name="", data=""):
        self.name = name
        self.data = data

    def add_name(self, name):
        self.name = name

    def add_data(self, data):
        self.data = data


class Warnings():
    def __init__(self):
        self.warnings = []

    def add_warning(self, warning):
        self.warnings.append(Warning(warning))


class Graphs():
    def __init__(self):
        self.multiplot = None
        self.plots = []

    def add_plot(self, name, plot):
        self.plots.append(Plot(name, plot))

    def change_multiplot(self, multiplot):
        self.multiplot = multiplot


class OutputFormat():
    def __init__(self):
        self.nodes = []

    def add_node(self, name):
        self.nodes.append(Node(name))

    def add_warning(self, message):
        self.nodes[-1].add_warning(message)

    def add_graph(self, name, plot):
        self.nodes[-1].add_graph(name, plot)


class CqeOutput():
    def __init__(self):
        self.nodes = []


class CqeNode():
    def __init__(self, name,driver=False):

        self.name = name
        self.warnings = []
        self.graph = []
        self.metadata: NodeMetadata = NodeMetadata()
        self.driver: bool = driver

    def add_warning(self, alert, time_value, threshold, time_threshold, warning, unit, fixed_value):
        self.warnings.append(CqeWarning(alert, round(time_value * 100, 2), threshold,
                                        round(time_threshold * 100, 2), warning, unit, fixed_value))

    def add_graph(self, label, data, thresholds, max_y):
        if data == "Time\n":
            thresholds = ''
        self.graph.append(CqePlot(label, data, thresholds, max_y))


class CqeWarning():
    def __init__(self, alert, time_value, threshold, time_threshold, warning, unit, fixed_value):
        self.time_threshold = time_threshold
        self.time_value = time_value
        self.warning = warning
        self.alert = alert
        self.threshold = threshold
        self.unit = unit
        self.fixed_value = fixed_value


class CqePlot():
    def __init__(self, label, data, thresholds, max_y):
        self.label = label
        self.data = data
        self.thresholds = thresholds
        self.max_y = max_y



class CqeOutputFormat():
    def __init__(self,job_id):
        self.nodes: List[CqeNode] = []
        self.metadata: TestrunMetadata = TestrunMetadata()
        self.id: int = job_id
        self.output_version = 0
    def add_node(self, name):
        self.nodes.append(CqeNode(name))

    def add_warning(self, message):
        self.nodes[-1].add_warning(message)

    def add_graph(self, name, plot):
        self.nodes[-1].add_graph(name, plot)


class TestInfo():
    def __init__(self, test_info,time_shift):
        self.duration: str = test_info['duration']
        self.id: str = test_info['id']
        self.name: str = test_info['name']
        self.provides: str = test_info['provides']
        self.result: str = test_info['result']
        self.tags: str = test_info['tags']
        dt = datetime.datetime.strptime(test_info['time'], "%a %b  %d %X %Y %z")
        timestamp = dt.replace(tzinfo=datetime.timezone.utc).timestamp() - (3600 * time_shift)
        self.time: int = int(timestamp)


class CoreInfo():
    def __init__(self, clock: float, cache: float, bogomips: float, label: str):
        self.clock: float = clock
        self.cache: float = cache
        self.bogomips: float = bogomips
        self.label: str = label


class StorageInfo():
    def __init__(self):
        pass


class NodeMetadata():
    def __init__(self):
        self.cores: List[CoreInfo] = []
        self.storages: List[StorageInfo] = []
        self.physical_memory: float = 0

    def add_cpu(self, clock: float, cache: float, bogomips: float, label: str):
        self.cores.append(CoreInfo(clock, cache, bogomips, label))


class TestrunMetadata():
    def __init__(self):
        self.tests = []

    def load_test_info(self, results_json: dict,time_shift: int):
        for test in results_json['tests']:
            self.tests.append(TestInfo(test,time_shift))
