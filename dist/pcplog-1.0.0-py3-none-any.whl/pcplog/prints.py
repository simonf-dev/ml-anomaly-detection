from os import sys
import copy
CPUS = ['cpu.idle', 'cpu.steal','cpu.systime', 'cpu.usertime', 'ksmd_utime+stime', 'mem.util.available']
GRAPH_STYLE_MULTI = 'set style fill transparent solid 0.5\n set border back\n set datafile missing "None"\n set y2tics\n'
GRAPH_STYLE = 'set style fill transparent solid 0.5\n set border back\n set datafile missing "None"\n'
THRESHOLD_X1 = "with filledcurves x1 title 'threshold' lt rgb 'red'\n"
THRESHOLD_X2 = "with filledcurves x2 title 'threshold' lt rgb 'red'\n"
DATE_STYLE = "set xdata time\nset format x ' %H:%M:%S'\n"
Y1_LABEL = "set ylabel '%s[%s]'\n"
Y2_LABEL = "set y2label '%s[%s]'\n"
CLEAR_EVERYTHING = "unset y2label\nunset ylabel\nunset title\n"
MULTIPRINT_TITLE = "set title '%s/%s'\n"

def print_result_chart(rate , result , threshold , time , error , metrics , node):
    message = "WARNING: \nValue of %s is %s %s of time over/below threshold\nThreshold is: %s \nAllowed percentage " \
              "of time over/below threshold is %s %s \nPossible error: %s\n" % (
                  rate , round(result * 100 , 2) , "%" , threshold , time * 100 , "%" , error)
    for i in metrics:
        message = message + ("Metric: %s\n%s" % (i.name , i.description)) + "\n"
    message = message + "\n"
    node.add_warning(message)


def print_result(rate , result , index , error , metrics , output):
    message = "WARNING: \n Value of %s is:  %s %s \n Threshold is: %s\n Possible error: %s\n" % (
        rate , result , metrics[0].get_unit() , index , error)
    output.add_warning(message)
    for i in metrics:
        output.add_warning("Metric: %s\n %s" % (i.name , i.description))
    output.add_warning('\n\n')


def graph_start(name , width , height , file=None , output=None):
    if output is not None:
        sys.stdout = open(output , "w")
    if file is not None:
        sys.stdout.write("set terminal png\nset output '%s'\n " % file)
    sys.stdout.write("set multiplot layout %s,%s title '%s' font ',14'" % (width , height , name))

def print_data(metrics):
    graph = ""
    for metric in metrics:
        for k in range(1 , len(metric.get_values(0))):
            for i in range(metric.get_size()):
                for j in metric.get_values(i):
                    graph = graph + "%s " % j
                graph = graph + "\n"
            graph = graph + 'e' + '\n'
    return graph
def multiprint(metrics , node , thresholds , graph_style , metrics_second , thresholds_second ,
               graph_style_second=None , minimum=0 , maximum=1):
    second_title = ""
    if graph_style_second:
        second_title = graph_style_second.title
    colour = 2
    for metric in metrics:
        if len(metric.units) >= 2:
            break
    graph = ''
    graph = graph + GRAPH_STYLE_MULTI
    graph = graph + DATE_STYLE
    graph = graph + MULTIPRINT_TITLE % (graph_style.title , second_title)
    xtic = 0
    max_tic = 0
    for metric in metrics:
        xtic = max(xtic , metric.get_time_value(len(metric.values) - 1) - metric.get_time_value(0))
        max_tic = max(max_tic , metric.get_time_value(len(metric.values) - 1))
        maximum = max(metric.get_max() , maximum)
    for metric in metrics_second:
        xtic = max(xtic , metric.get_time_value(len(metric.values) - 1) - metric.get_time_value(0))
        max_tic = max(max_tic , metric.get_time_value(len(metric.values) - 1))
        maximum = max(metric.get_max() , maximum)

    xtic = (xtic // 3) - (xtic % 30)
    thresholds_values = list(map(lambda x: x.value , thresholds))
    graph = graph + "set yrange[%s:%s]\n" % (minimum , max((max(thresholds_values or [0])) , maximum) * 1.5)
    thresholds_values = list(map(lambda x: x.value , thresholds_second))
    graph = graph + "set y2range[%s:%s]\n" % (minimum , max((max(thresholds_values or [0])) , maximum) * 1.5)

    graph = graph + Y1_LABEL % (graph_style.description , graph_style.units)
    if graph_style_second:
        graph = graph + Y2_LABEL % (graph_style_second.description , graph_style_second.units)
    graph = graph + "plot"


    for metric in metrics:
        for i in range(1 , len(metric.get_values(0))):
            graph = graph + "'-' using ($1):%s  with lines  axes x1y1  lw 2 lt %s title '%s[%s]' , " % (
                i + 1 , colour , metric.unit_names[i] , graph_style.units)
            colour += 1
    colour = 2

    for index in range(len(metrics)):
        position = "below"
        if (thresholds[index].over == True):
            position = "above"
        for i in range(1 , len(metrics[index].get_values(0))):
            graph = graph + "'-' using ($1):%s with filledcurves   %s y1=%s   axes x1y1 lt %s notitle  , " % (
                i + 1 , position , thresholds[index].value , colour)
            colour += 1
    remember = colour
    for metric in metrics_second:
        for i in range(1 , len(metric.get_values(0))):
            graph = graph + "'-' using ($1):%s  with lines axes x1y2 lw 2 lt %s title '%s[%s]' , " % (
                i + 1 , colour , metric.unit_names[i] , graph_style_second.units)
            colour += 1
    colour = remember
    for index in range(len(metrics_second)):
        position = "below"
        if thresholds_second[index].over == True:
            position = "above"
        for i in range(1 , len(metrics_second[index].get_values(0))):
            graph = graph + "'-' using ($1):%s with filledcurves   %s y2=%s   axes x1y2 lt %s notitle  , " % (
                i + 1 , position , thresholds_second[index].value , colour)
            colour += 1

    graph = graph + '\n'
    for i in range(2):
        graph = graph + print_data(metrics)
    for i in range(2):
        graph = graph + print_data(metrics_second)
    graph = graph + CLEAR_EVERYTHING

    node.add_graph(graph_style.title , graph)


def graph_print(metric , node , threshold=-1 , title=None , over=True , minimum=0 , maximum=1):
    colour = 2
    if len(metric.units) < 2:
        return
    graph = ''
    if title is None:
        title = metric.name
    xtic = (metric.get_time_value(len(metric.values) - 1) - metric.get_time_value(0)) // 3
    xtic = xtic - (xtic % 30)
    graph = graph + GRAPH_STYLE
    graph = graph + "set xtics 0,%s,%s\n" % (xtic , metric.values[len(metric.values) - 1][0])
    graph = graph + "set yrange[%s:%s]\n" % (minimum , max([threshold , maximum]) * 1.5)
    graph = graph + DATE_STYLE
    graph = graph + "set title ' %s'\n" % title
    metric.description = metric.description.replace('\n' , ' ')
    graph = graph + "set ylabel '%s[%s]'\n" % (metric.description , metric.units[1])
    graph = graph + "plot '-' using ($1):2 with lines lw 2 lt 2 title '%s' " % metric.unit_names[1]
    for i in range(2 , len(metric.get_values(0))):
        colour += 1
        graph = graph + ", '-' using ($1):%s with lines lw 2 lt %s title '%s'" % (i + 1 , colour , metric.unit_names[i])
    if threshold != -1:
        graph = graph + ",  %s" % threshold
        if over:
            graph = graph + THRESHOLD_X2
        else:
            graph = graph + THRESHOLD_X1
    graph = graph + '\n'
    for k in range(1 , len(metric.get_values(0))):
        for i in range(metric.get_size()):
            for j in metric.get_values(i):
                graph = graph + "%s " % j
            graph = graph + "\n"
        graph = graph + 'e' + '\n'
    node.add_graph(title , graph)

def datafile_output(metrics):
    output_string = ""

    minimum = 20000000000
    maximum = 0
    for metric in  metrics:
        maximum = max(maximum,metric.values[-1][0])
        minimum = min(maximum,metric.values[0][0])
    for time in range (minimum,maximum +1):
        values = []
        for metric in metrics:
            values += metric.get_value_by_time(time)
        if len (list(filter(lambda x: x is not None,values))) != 0:
            output_string += str(time)
            output_string += " "
            output_string += (' '.join(str(value) for value in values)) + '\n'
    return output_string

def get_first_unitname(metric):
    return metric.get_name_value(1)
def datafile_output_variables(metrics,labels,thresholds):
    metrics.sort(key=get_first_unitname)
    thresholds.sort(key=get_first_unitname)
    output_string = ""
    if len(metrics) != len(labels):
        for i in range(len(labels)):
            try:
                if labels[i] != metrics[i].unit_names[1]:
                    metrics.insert(i,None)
            except:
                metrics.append(None)
    minimum = 20000000000
    maximum = 0
    for metric in  metrics:
        if metric is not None:
            maximum = max(maximum,metric.values[-1][0])
            minimum = min(maximum,metric.values[0][0])

    for time in range (minimum,maximum +1):
        values = []
        for metric in metrics:
            if metric is None:
                values += [None]
            else:
                values += metric.get_value_by_time(time)
        if len (list(filter(lambda x: x is not None,values))) != 0:
            output_string += str(time)
            output_string += " "
            output_string += (' '.join(str(value) for value in values)) + '\n'
    return output_string,thresholds


def cqe_warning_output(warning_message):
    return "WARNING: \n Value of {alert} is {time_value} %s of time over/below threshold\nValue threshold is: {threshold} {unit} \nAllowed percentage " \
              "of time over/below threshold is {time_threshold} %s or {fixed_value} seconds \nPossible error: %s\n" % ("%","%",warning_message)


def multiply_thresholds(nodes,thresholds):
    new_thresholds =  []
    for node_i in range(len(nodes)):
        if len(nodes[node_i].values) != 0:
            for i in range(len(nodes[node_i].values[0]) - 1):
                new_thresholds.append(copy.deepcopy(thresholds[node_i]))
    return new_thresholds
def return_values_thresholds(node,label):
    if node.get(label):
        return node[label][0],node[label][1]
    return [],[]