import os

TIMEFRAME = 1
CURRENT_DIR = os.getcwd()

TEST_PARAMETERS = os.path.dirname(__file__) + "/./data/test_parameters.json"
CHART_METRICS_PATH = os.path.dirname(__file__) + "/./data/chart_metrics.json"
BASIC_METRICS_PATH = os.path.dirname(__file__) + "/./data/basic_metrics.json"
CHART_GROUPS_PATH = os.path.dirname(__file__) + "/./data/chart_groups.json"
DATA_DIRECTORY = os.path.dirname(__file__) + "/./data/"
TESTING_PCP_OUTPUT_DATA = os.path.dirname(__file__) + "/./tests_dev/testing_pcpoutput_data/"
BEAKER_URL = ""
BEAKER_PROXY_SERVER = ''
